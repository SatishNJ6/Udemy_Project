package java_part2;

public class superKeywordParent {
	String name = "Nihit";

	public superKeywordParent() {
		System.out.println("parent class constructor");
	}

	public void getData() {
		System.out.println("I am in parent class");
	}

}
