package java_part1;

public class FoorLoop {

	public static void main(String[] args) {

		// 1 to 10

		/*
		 * for(initialization;condition;increment) {
		 * 
		 * }
		 */

		for (int i = 0; i < 10; i = i + 3) {
			if (i == 9)
				System.out.println(" 9 is displayed");
			else
				System.out.println("I did not find");//
		}
	}

}
