package java_part1;

public class WhileLoop {

	public static void main(String[] args) {
		// While loop

		// 1 to 10
		int i = 10;

		while (i > 0) {
			System.out.println(i);
			i--;// i=2
		}

		int j = 20;
		do {
			System.out.println(j);
			j++;

		} while (j > 30);// 1 loop of execution is guarantee

	}

}
