package java_part1;

public abstract class ParentAircraft_AbstracClass {

	public void engine() {
		System.out.println("follow engine guidelines");
	}

	public void safetyGuideLines() {
		System.out.println("follow safety guidelines");
	}

	public abstract void bodyColour();

}
