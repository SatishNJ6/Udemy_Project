package java_part1;

public interface ContinentalTraffic_Interface {

	void trainSymbol();

}
