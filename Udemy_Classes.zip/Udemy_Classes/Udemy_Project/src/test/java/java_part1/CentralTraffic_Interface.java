package java_part1;

public interface CentralTraffic_Interface {

	public void goGreen();

	public void stopRed();

	public void flashYellow();

}
