package java_part1;

public class ParentClass_Inheritance {

	String name = "Rahul";

	public ParentClass_Inheritance() {
		System.out.println("Parent class construtor");

	}

	public void getData() {
		System.out.println(" I am parent class");
	}

}
