package java_part1;

public class IfElse {

	public static void main(String[] args) {
		if (5 > 2) {

			System.out.println("success");
			System.out.println("second step");
		}

		else

			System.out.println("fail");

	}

}
