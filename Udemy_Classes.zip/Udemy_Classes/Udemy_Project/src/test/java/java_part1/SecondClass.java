package java_part1;

public class SecondClass {

	public void setData() {
		System.out.println("I am in a second method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
