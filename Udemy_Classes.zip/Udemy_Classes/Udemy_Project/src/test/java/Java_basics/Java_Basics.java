package Java_basics;

public class Java_Basics {

	// words which are in red color are java keywords
	// code execution starts in main block
	// java code will not execute if we write the code outside of main block

	public static void main(String[] args) {
		int a = 2;
		int b = 3;
		int sum = a + b; // adding 2 numbers
		System.out.println("I am learning Java"); // statement to print in console

		System.out.println("sum is" + "\t" + sum);

	}

}
