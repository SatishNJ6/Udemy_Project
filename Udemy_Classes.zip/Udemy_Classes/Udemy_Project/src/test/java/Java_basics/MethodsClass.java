package Java_basics;

public class MethodsClass {

	public int validateHeader() {
		System.out.println("verify header links");
		return 2;
	}

}
